You need to install a firmware at your ftDuino and at your ftSwarmDuino.
Use ftDuino to flash your ftDuino.
Use ftSwarmDuino to flash your ftSwarmDuino.
Keep in mind of board settings!