/*
 * SwOSWEB.h
 *
 * fTSwarm buildin WebServer
 * 
 * (C) 2021/22 Christian Bergschneider & Stefan Fuss
 * 
 */
 
#pragma once

bool SwOSStartWebServer(void);
